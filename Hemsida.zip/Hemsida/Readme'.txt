Templates = HTML FILER
STATIC = css filer
Utanföringen map ba hemsida all js,python och övrig kod